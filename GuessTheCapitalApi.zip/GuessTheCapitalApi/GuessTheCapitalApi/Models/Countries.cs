﻿using System;
using System.Collections.Generic;

namespace GuessTheCapitalApi.Models
{
    public partial class Countries
    {
        public int Id { get; set; }
        public string CountryName { get; set; }
        public string Capital { get; set; }
        public string Flag { get; set; }
        public string Continent { get; set; }
    }
}
