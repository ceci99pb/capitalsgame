﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GuessTheCapitalApi.Models
{
    public partial class GuessTheCapitalContext : DbContext
    {
        public GuessTheCapitalContext()
        {
        }

        public GuessTheCapitalContext(DbContextOptions<GuessTheCapitalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Countries> Countries { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=W10L-CECILIBE\\SQLEXPRESS;Initial Catalog=GuessTheCapital;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Countries>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Capital)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Continent)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.CountryName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Flag).HasMaxLength(50);
            });
        }
    }
}
